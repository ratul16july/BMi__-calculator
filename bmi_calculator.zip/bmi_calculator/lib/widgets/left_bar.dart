import 'package:bmi_calculator/constraints/app_constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
class LeftBar extends StatelessWidget {
  final double barWidth;
  @override
  const LeftBar({Key? key, required this.barWidth}) : super(key: key);


  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          height: 25,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                bottomLeft: Radius.circular(20),
              ),
              color: accentHexColor),
          width: barWidth,
        ),
      ],
    );
  }
}